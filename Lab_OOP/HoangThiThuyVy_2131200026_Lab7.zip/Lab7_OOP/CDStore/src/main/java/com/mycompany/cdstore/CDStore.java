/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.cdstore;

import java.util.*;

/**
 *
 * @author Student
 */
public class CDStore {

    public static void main(String[] args) {
        new CD_Store().setVisible(true);

    }

}
