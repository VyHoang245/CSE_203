/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.resortpricecalculator;

/**
 *
 * @author vygir
 */
public class ResortPriceCalculator {

    public static void main(String[] args) {
         new CalculatorFrame().setVisible(true);
    }
}
